import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { EmployeeComponent } from './employee/employee.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { AuthguardserviceService } from './services/authguardservice.service';


const routes: Routes = [
  // {path : '', redirectTo:'login',pathMatch:"full"},
  {path: '',component:HomeComponent},
  {path :'login' , component : LoginComponent},
  {path :'employee' , component : EmployeeComponent},
  {path:'Admin',component:AdminComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
